public class Connection {
    City city;
    int distance;

    public Connection(City city, Integer distance) {
        this.city = city;
        this.distance = distance;
    }
}
